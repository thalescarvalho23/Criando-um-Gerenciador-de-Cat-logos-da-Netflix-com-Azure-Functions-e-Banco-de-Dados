# Gerenciador de Catálogos da Netflix com Azure Functions e Banco de Dados  

Este projeto demonstra como criar um sistema de gerenciamento de catálogos de filmes e séries, inspirado na Netflix, utilizando **Azure Functions** para lógica serverless, **CosmosDB** para banco de dados NoSQL e **Azure Storage Account** para armazenamento de arquivos.  

A solução proposta aborda a criação da infraestrutura em nuvem e o desenvolvimento de funções específicas para manipulação de dados e arquivos, tornando o sistema escalável, eficiente e fácil de gerenciar.  

---

## Estrutura do Projeto  

1. **Criando a Infraestrutura em Cloud.**  
2. **Azure Function para Salvar Arquivos no Storage Account.**  
3. **Azure Function para Salvar Registros no CosmosDB.**  
4. **Azure Function para Filtrar Registros no CosmosDB.**  
5. **Azure Function para Listar Registros no CosmosDB.**  

---

## 1. Criando a Infraestrutura em Cloud  

Para suportar as funcionalidades do sistema, configuramos os seguintes serviços na **Microsoft Azure**:  

### Recursos Utilizados:  
- **Azure Functions**: Para implementar a lógica de negócios de forma serverless.  
- **Azure CosmosDB**: Para armazenar informações do catálogo com flexibilidade e escalabilidade.  
- **Azure Storage Account**: Para gerenciar arquivos, como capas de filmes e imagens promocionais.  

### Passos de Configuração:  

1. **Criar um Resource Group**  
   Um Resource Group organiza os recursos utilizados em um único ambiente gerenciável.  
   ```bash
   az group create --name NetflixCatalogRG --location eastus
